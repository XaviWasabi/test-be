<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/preparation-time" only-nested=true }}
{{attribute name="preparation-time-iso8601-duration" }}
