# Accordion

The Accordion Field in Advanced Custom Fields that lets users separate other fields in collapsible
sections.

This field is for administrative display purposes and is not exposed in WPGraphQL.

----

- **Next Field:** [Button Group](./button-group.md)
